
import React from 'react';
import { Topic } from '../types';
import TopicCard from '../components/TopicCard';
import { COURSE_TOPICS } from '../constants';

const DashboardPage: React.FC = () => {
  const topics: Topic[] = COURSE_TOPICS;

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-bold text-brand-dark">Course Dashboard</h1>
        <p className="text-xl text-gray-600 mt-2">Explore our curated topics to master look maxxing.</p>
      </div>
      
      {topics.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {topics.map((topic) => (
            <TopicCard key={topic.id} topic={topic} />
          ))}
        </div>
      ) : (
        <p className="text-center text-gray-500 text-lg">No topics available at the moment. Check back soon!</p>
      )}
      
      <div className="mt-16 text-center">
        <p className="text-gray-700">Ready to dive deeper? Select a topic to begin your transformation.</p>
      </div>
    </div>
  );
};

export default DashboardPage;
