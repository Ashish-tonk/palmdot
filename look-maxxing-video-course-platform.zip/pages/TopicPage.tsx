
import React, { useState, useEffect } from 'react';
import { useParams, Link, Navigate } from 'react-router-dom';
import { Topic, Resource, ResourceType } from '../types';
import { COURSE_TOPICS } from '../constants';
import LoadingSpinner from '../components/LoadingSpinner';
import Modal from '../components/Modal';

const VideoIcon: React.FC = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-2 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.55a1 1 0 011.45.89v2.22a1 1 0 01-1.45.89L15 12M4 6h11M4 10h11M4 14h5m-5 4h5" />
  </svg>
);

const PdfIcon: React.FC = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-2 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
  </svg>
);

const TopicPage: React.FC = () => {
  const { topicId } = useParams<{ topicId: string }>();
  const [topic, setTopic] = useState<Topic | null | undefined>(undefined); // undefined for loading, null for not found
  const [selectedResource, setSelectedResource] = useState<Resource | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    // Simulate fetching topic data
    const foundTopic = COURSE_TOPICS.find(t => t.id === topicId);
    setTopic(foundTopic || null);
  }, [topicId]);

  const openResourceModal = (resource: Resource) => {
    setSelectedResource(resource);
    setIsModalOpen(true);
  };

  const closeResourceModal = () => {
    setIsModalOpen(false);
    setSelectedResource(null);
  };

  if (topic === undefined) {
    return <LoadingSpinner />;
  }

  if (topic === null) {
    return <Navigate to="/dashboard" replace />;
  }

  const videos = topic.resources.filter(r => r.type === ResourceType.VIDEO);
  const pdfs = topic.resources.filter(r => r.type === ResourceType.PDF);

  return (
    <div className="container mx-auto px-4 py-8">
      <Link to="/dashboard" className="text-brand-primary hover:underline mb-6 inline-block">&larr; Back to Dashboard</Link>
      
      <div className="bg-white shadow-xl rounded-lg p-6 md:p-10 mb-12">
        <img src={topic.thumbnail} alt={topic.title} className="w-full h-64 md:h-96 object-cover rounded-lg mb-6 shadow-md" />
        <h1 className="text-4xl md:text-5xl font-bold text-brand-dark mb-4">{topic.title}</h1>
        <p className="text-gray-700 text-lg leading-relaxed mb-2">{topic.longDescription || topic.description}</p>
      </div>

      {videos.length > 0 && (
        <section className="mb-12">
          <h2 className="text-3xl font-semibold text-brand-dark mb-6 border-b-2 border-brand-primary pb-2">Videos</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {videos.map(video => (
              <div key={video.id} className="bg-white rounded-lg shadow-lg overflow-hidden transform transition-all hover:shadow-xl hover:-translate-y-1">
                {video.thumbnail && <img src={video.thumbnail} alt={video.title} className="w-full h-40 object-cover"/>}
                <div className="p-5">
                  <h3 className="text-xl font-semibold text-brand-dark mb-2 flex items-center"><VideoIcon /> {video.title}</h3>
                  <p className="text-gray-600 text-sm mb-3 line-clamp-2">{video.description}</p>
                  {video.duration && <p className="text-xs text-gray-500 mb-3">Duration: {video.duration}</p>}
                  <button 
                    onClick={() => openResourceModal(video)}
                    className="w-full bg-red-500 hover:bg-red-600 text-white font-semibold py-2 px-4 rounded-md transition-colors flex items-center justify-center"
                  >
                    <VideoIcon /> Watch Video
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {pdfs.length > 0 && (
        <section>
          <h2 className="text-3xl font-semibold text-brand-dark mb-6 border-b-2 border-brand-primary pb-2">PDF Resources</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {pdfs.map(pdf => (
              <div key={pdf.id} className="bg-white rounded-lg shadow-lg p-5 transform transition-all hover:shadow-xl hover:-translate-y-1">
                 <h3 className="text-xl font-semibold text-brand-dark mb-2 flex items-center"><PdfIcon /> {pdf.title}</h3>
                <p className="text-gray-600 text-sm mb-3 line-clamp-2">{pdf.description}</p>
                {pdf.pages && <p className="text-xs text-gray-500 mb-3">Pages: {pdf.pages}</p>}
                <button 
                  onClick={() => openResourceModal(pdf)}
                  className="w-full bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded-md transition-colors flex items-center justify-center"
                >
                  <PdfIcon /> View PDF
                </button>
              </div>
            ))}
          </div>
        </section>
      )}

      {selectedResource && (
        <Modal isOpen={isModalOpen} onClose={closeResourceModal} title={selectedResource.title}>
          <div className="py-4">
            <p className="text-gray-700 mb-4">{selectedResource.description}</p>
            {selectedResource.type === ResourceType.VIDEO && selectedResource.thumbnail && (
                 <img src={selectedResource.thumbnail} alt={selectedResource.title} className="w-full h-auto rounded-md mb-4 shadow-lg"/>
            )}
            {selectedResource.type === ResourceType.VIDEO ? (
              <div>
                <h4 className="text-lg font-semibold mb-2">Video Player Placeholder</h4>
                <div className="bg-gray-800 text-white aspect-video w-full flex items-center justify-center rounded-md">
                  <p>Video player for "{selectedResource.title}" would be here.</p>
                </div>
                {selectedResource.url !== '#' && <p className="mt-2 text-sm">Source: <a href={selectedResource.url} target="_blank" rel="noopener noreferrer" className="text-brand-primary hover:underline">{selectedResource.url}</a></p>}
              </div>
            ) : (
              <div>
                <h4 className="text-lg font-semibold mb-2">PDF Viewer Placeholder</h4>
                <div className="bg-gray-200 p-8 text-center rounded-md">
                  <p>PDF content for "{selectedResource.title}" would be displayed here.</p>
                  {selectedResource.url !== '#' && <a href={selectedResource.url} target="_blank" rel="noopener noreferrer" className="mt-4 inline-block bg-brand-primary text-white py-2 px-4 rounded hover:bg-blue-700">Download/Open PDF</a>}
                </div>
              </div>
            )}
          </div>
        </Modal>
      )}
    </div>
  );
};

export default TopicPage;
