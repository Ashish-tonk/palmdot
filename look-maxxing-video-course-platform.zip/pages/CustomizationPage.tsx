
import React, { useState, useCallback } from 'react';
import { generateCustomizationPlan } from '../services/geminiService';
import LoadingSpinner from '../components/LoadingSpinner';

// Helper to parse markdown-like text to basic HTML for display
const MarkdownRenderer: React.FC<{ text: string }> = ({ text }) => {
  const formatText = (inputText: string) => {
    let html = inputText;
    // Bold: **text** or __text__
    html = html.replace(/\*\*(.*?)\*\*|__(.*?)__/g, '<strong>$1$2</strong>');
    // Italics: *text* or _text_
    html = html.replace(/\*(.*?)\*|_(.*?)_/g, '<em>$1$2</em>');
    // Headings: #, ##, ###
    html = html.replace(/^### (.*$)/gim, '<h3 class="text-xl font-semibold mt-3 mb-1">$1</h3>');
    html = html.replace(/^## (.*$)/gim, '<h2 class="text-2xl font-semibold mt-4 mb-2">$1</h2>');
    html = html.replace(/^# (.*$)/gim, '<h1 class="text-3xl font-bold mt-5 mb-3">$1</h1>');
    // Unordered lists: * or - or +
    html = html.replace(/^\s*[-*+] (.*)/gm, '<li class="ml-6 list-disc">$1</li>');
    html = html.replace(/((<li.*<\/li>\s*)+)/g, '<ul class="mb-3">$1</ul>');
    // Paragraphs (simple line breaks)
    html = html.split('\n').map(p => p.trim() === '' ? '<br/>' : `<p class="mb-2 leading-relaxed">${p}</p>`).join('');
    // Clean up multiple <br/> and empty paragraphs more effectively
    html = html.replace(/(<br\s*\/?>\s*){2,}/gi, '<br/>'); // Consolidate multiple breaks
    html = html.replace(/<p class="mb-2 leading-relaxed">\s*<br\s*\/?>\s*<\/p>/gi, ''); // Remove paragraphs that only contain a break
    html = html.replace(/<p class="mb-2 leading-relaxed">\s*<\/p>/gi, ''); // Remove empty paragraphs
    
    return html;
  };

  return <div dangerouslySetInnerHTML={{ __html: formatText(text) }} />;
};


const CustomizationPage: React.FC = () => {
  const [userInput, setUserInput] = useState<string>('');
  const [generatedPlan, setGeneratedPlan] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userInput.trim()) {
      setError("Please describe your course ideas first.");
      return;
    }
    setIsLoading(true);
    setError(null);
    setGeneratedPlan(null);

    try {
      const plan = await generateCustomizationPlan(userInput);
      setGeneratedPlan(plan);
    } catch (err: any) {
      setError(err.message || "Failed to generate plan. Check console for details.");
      console.error("Gemini API error details:", err);
    } finally {
      setIsLoading(false);
    }
  }, [userInput]);

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="bg-white shadow-xl rounded-lg p-6 md:p-10">
        <h1 className="text-3xl md:text-4xl font-bold text-brand-dark mb-6 text-center">
          ✨ AI-Powered Course Customization ✨
        </h1>
        <p className="text-gray-600 mb-8 text-center text-lg">
          Describe your vision for your 'look maxxing' course. Our AI will help you craft a unique website plan,
          suggesting selling points, audience engagement ideas, and content structure.
        </p>

        <form onSubmit={handleSubmit} className="space-y-6 mb-10">
          <div>
            <label htmlFor="userInput" className="block text-sm font-medium text-gray-700 mb-1">
              Your Course Ideas & Goals:
            </label>
            <textarea
              id="userInput"
              rows={8}
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
              className="w-full p-3 border border-gray-300 rounded-md shadow-sm focus:ring-brand-primary focus:border-brand-primary"
              placeholder="E.g., 'My course focuses on skincare for men over 30, advanced hairstyling techniques, and building confidence through style. I want to target busy professionals...'"
            />
          </div>
          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-brand-accent hover:bg-amber-600 text-white font-bold py-3 px-6 rounded-lg shadow-md hover:shadow-lg transition-all duration-300 disabled:bg-gray-400 flex items-center justify-center space-x-2"
          >
            {isLoading && (
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
            )}
            <span>{isLoading ? 'Generating Your Plan...' : 'Generate Customization Plan'}</span>
          </button>
        </form>

        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-md relative mb-6" role="alert">
            <strong className="font-bold">Oops! </strong>
            <span className="block sm:inline">{error}</span>
          </div>
        )}

        {generatedPlan && (
          <div className="mt-10 p-6 bg-gray-50 rounded-lg border border-gray-200 shadow">
            <h2 className="text-2xl font-semibold text-brand-dark mb-4">Your Custom Website Plan:</h2>
            <div className="prose prose-lg max-w-none text-gray-700">
               <MarkdownRenderer text={generatedPlan} />
            </div>
          </div>
        )}
         {!isLoading && !generatedPlan && !error && (
          <div className="mt-10 p-6 bg-blue-50 rounded-lg border border-blue-200 text-center">
            <p className="text-blue-700">Your generated plan will appear here once you submit your ideas.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default CustomizationPage;
