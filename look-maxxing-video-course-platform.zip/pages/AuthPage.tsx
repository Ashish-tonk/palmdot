
import React, { useState } from 'react';
import AuthForm from '../components/AuthForm';
import { AuthState } from '../types';
import { APP_TITLE } from '../constants';

interface AuthPageProps {
  onLogin: (email: string, pass: string) => Promise<void>;
  onSignup: (email: string, pass: string) => Promise<void>;
  authState: AuthState;
}

const AuthPage: React.FC<AuthPageProps> = ({ onLogin, onSignup, authState }) => {
  const [isLoginView, setIsLoginView] = useState(true);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-4">
      <div className="text-center mb-10">
        <h1 className="text-5xl font-extrabold text-white drop-shadow-lg">{APP_TITLE}</h1>
        <p className="text-xl text-purple-300 mt-2">Unlock Your Potential</p>
      </div>
      
      <div className="bg-white p-8 md:p-10 rounded-xl shadow-2xl w-full max-w-md">
        {isLoginView ? (
          <AuthForm
            onSubmit={onLogin}
            buttonText="Login"
            isLoading={authState.isLoading}
            error={authState.error}
          />
        ) : (
          <AuthForm
            onSubmit={onSignup}
            buttonText="Sign Up"
            isLoading={authState.isLoading}
            error={authState.error}
          />
        )}
        <p className="mt-8 text-center text-sm text-gray-600">
          {isLoginView ? "Don't have an account? " : "Already have an account? "}
          <button
            onClick={() => setIsLoginView(!isLoginView)}
            className="font-medium text-brand-primary hover:text-blue-700"
          >
            {isLoginView ? 'Sign up here' : 'Login here'}
          </button>
        </p>
      </div>
    </div>
  );
};

export default AuthPage;
