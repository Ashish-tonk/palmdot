
import React from 'react';
import { Link } from 'react-router-dom';
import { User } from '../types';
import { APP_TITLE } from '../constants';

interface NavbarProps {
  user: User | null;
  onLogout: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ user, onLogout }) => {
  return (
    <nav className="bg-brand-dark text-white shadow-lg">
      <div className="container mx-auto px-6 py-3 flex justify-between items-center">
        <Link to={user ? "/dashboard" : "/"} className="text-2xl font-bold hover:text-brand-primary transition-colors">
          {APP_TITLE}
        </Link>
        <div className="space-x-4">
          {user ? (
            <>
              <Link to="/dashboard" className="hover:text-brand-primary transition-colors">Dashboard</Link>
              <Link to="/customize" className="hover:text-brand-primary transition-colors">Customize Plan</Link>
              <button 
                onClick={onLogout} 
                className="bg-brand-primary hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded transition-colors"
              >
                Logout ({user.email})
              </button>
            </>
          ) : (
            <span className="text-sm text-gray-300">Welcome, Guest!</span>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
