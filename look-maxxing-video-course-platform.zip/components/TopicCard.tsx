
import React from 'react';
import { Link } from 'react-router-dom';
import { Topic } from '../types';

interface TopicCardProps {
  topic: Topic;
}

const TopicCard: React.FC<TopicCardProps> = ({ topic }) => {
  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden transform transition-all hover:shadow-2xl hover:-translate-y-1 duration-300">
      <img className="w-full h-48 object-cover" src={topic.thumbnail} alt={topic.title} />
      <div className="p-6">
        <h3 className="text-2xl font-semibold text-brand-dark mb-2">{topic.title}</h3>
        <p className="text-gray-600 text-sm mb-4 line-clamp-3">{topic.description}</p>
        <Link
          to={`/topic/${topic.id}`}
          className="inline-block bg-brand-primary hover:bg-blue-700 text-white font-semibold py-2 px-6 rounded-lg shadow-md hover:shadow-lg transition-all duration-300"
        >
          View Topic
        </Link>
      </div>
    </div>
  );
};

export default TopicCard;
