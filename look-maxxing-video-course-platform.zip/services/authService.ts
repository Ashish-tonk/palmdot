
import { User } from '../types';

const USER_KEY = 'lookmaxxing_user';

export const authService = {
  signup: async (email: string, _password?: string): Promise<User> => {
    // In a real app, hash password and call backend API
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if (localStorage.getItem(USER_KEY) && JSON.parse(localStorage.getItem(USER_KEY)!).email === email) {
          reject(new Error('User already exists with this email.'));
          return;
        }
        const user: User = { email };
        localStorage.setItem(USER_KEY, JSON.stringify(user));
        resolve(user);
      }, 500);
    });
  },

  login: async (email: string, _password?: string): Promise<User> => {
    // In a real app, validate credentials with backend API
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const storedUser = localStorage.getItem(USER_KEY);
        if (storedUser) {
          const user: User = JSON.parse(storedUser);
          if (user.email === email) {
            resolve(user);
            return;
          }
        }
        reject(new Error('Invalid email or password. (Simulated)'));
      }, 500);
    });
  },

  logout: (): void => {
    localStorage.removeItem(USER_KEY);
  },

  getCurrentUser: (): User | null => {
    const storedUser = localStorage.getItem(USER_KEY);
    return storedUser ? JSON.parse(storedUser) : null;
  },
};
