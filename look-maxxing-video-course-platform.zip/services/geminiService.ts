
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { GEMINI_MODEL_TEXT } from '../constants';

// Ensure API_KEY is accessed from process.env
// In a real Vite/Create React App setup, this would be process.env.REACT_APP_API_KEY or process.env.VITE_API_KEY
// For this environment, we assume process.env.API_KEY is directly available.
const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.error("API_KEY for Gemini is not set. Please set the process.env.API_KEY environment variable.");
  // Potentially throw an error or disable AI features if running in an environment where it's critical
  // For this example, we'll allow the app to run but Gemini features will fail.
}

const ai = new GoogleGenAI({ apiKey: API_KEY! }); // Use non-null assertion as API_KEY check is above

export const generateCustomizationPlan = async (userInput: string): Promise<string> => {
  if (!API_KEY) {
    return Promise.reject("Gemini API key not configured. Cannot generate plan.");
  }
  try {
    const prompt = `
      You are an expert course creation and website design consultant for a 'look maxxing' course.
      Based on the following user input, generate a concise and actionable plan for their customized course website.
      Focus on:
      1.  Unique Selling Propositions (USPs) derived from their input.
      2.  Target audience engagement strategies.
      3.  Key content pillars or sections for the website.
      4.  Suggestions for a catchy tagline or a brief mission statement for the course.
      Keep the output structured, perhaps using markdown for headings and lists.

      User input: "${userInput}"

      Provide your plan below:
    `;

    const response: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_MODEL_TEXT,
      contents: prompt,
      config: {
        temperature: 0.7,
        topP: 0.95,
        topK: 64,
      }
    });
    
    return response.text;

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    if (error instanceof Error) {
        return Promise.reject(`Failed to generate plan: ${error.message}`);
    }
    return Promise.reject("An unknown error occurred while generating the plan.");
  }
};
