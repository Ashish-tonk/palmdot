
import React, { useState, useEffect, useCallback } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import Navbar from './components/Navbar';
import AuthPage from './pages/AuthPage';
import DashboardPage from './pages/DashboardPage';
import TopicPage from './pages/TopicPage';
import CustomizationPage from './pages/CustomizationPage';
import { authService } from './services/authService';
import { User, AuthState } from './types';

const App: React.FC = () => {
  const [authState, setAuthState] = useState<AuthState>({
    user: null,
    isLoading: true,
    error: null,
  });

  useEffect(() => {
    const currentUser = authService.getCurrentUser();
    setAuthState({ user: currentUser, isLoading: false, error: null });
  }, []);

  const handleLogin = useCallback(async (email: string, pass: string) => {
    setAuthState(prev => ({ ...prev, isLoading: true, error: null }));
    try {
      const user = await authService.login(email, pass);
      setAuthState({ user, isLoading: false, error: null });
    } catch (err: any) {
      setAuthState({ user: null, isLoading: false, error: err.message || 'Login failed' });
    }
  }, []);

  const handleSignup = useCallback(async (email: string, pass: string) => {
    setAuthState(prev => ({ ...prev, isLoading: true, error: null }));
    try {
      const user = await authService.signup(email, pass);
      setAuthState({ user, isLoading: false, error: null });
    } catch (err: any) {
      setAuthState({ user: null, isLoading: false, error: err.message || 'Signup failed' });
    }
  }, []);

  const handleLogout = useCallback(() => {
    authService.logout();
    setAuthState({ user: null, isLoading: false, error: null });
  }, []);

  if (authState.isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-brand-dark">
        <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-brand-primary"></div>
      </div>
    );
  }

  // Protected Route Component
  const ProtectedRoute: React.FC<{ children: React.ReactElement }> = ({ children }) => {
    if (!authState.user) {
      return <Navigate to="/" replace />;
    }
    return children;
  };
  
  // Auth Route Component (redirect if logged in)
  const AuthRoute: React.FC<{ children: React.ReactElement }> = ({ children }) => {
    if (authState.user) {
      return <Navigate to="/dashboard" replace />;
    }
    return children;
  };


  return (
    <HashRouter>
      <div className="flex flex-col min-h-screen">
        <Navbar user={authState.user} onLogout={handleLogout} />
        <main className="flex-grow bg-brand-light">
          <Routes>
            <Route 
              path="/" 
              element={
                <AuthRoute>
                  <AuthPage onLogin={handleLogin} onSignup={handleSignup} authState={authState} />
                </AuthRoute>
              } 
            />
            <Route 
              path="/dashboard" 
              element={
                <ProtectedRoute>
                  <DashboardPage />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/topic/:topicId" 
              element={
                <ProtectedRoute>
                  <TopicPage />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/customize" 
              element={
                <ProtectedRoute>
                  <CustomizationPage />
                </ProtectedRoute>
              } 
            />
            <Route path="*" element={<Navigate to={authState.user ? "/dashboard" : "/"} replace />} />
          </Routes>
        </main>
        <footer className="bg-brand-dark text-white text-center p-4 shadow-inner">
          <p>&copy; {new Date().getFullYear()} Look Maxxing Mastery. All rights reserved.</p>
        </footer>
      </div>
    </HashRouter>
  );
};

export default App;
