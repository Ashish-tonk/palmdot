
import { Topic, ResourceType } from './types';

export const APP_TITLE = "Look Maxxing Mastery";

export const GEMINI_MODEL_TEXT = 'gemini-2.5-flash-preview-04-17';

export const COURSE_TOPICS: Topic[] = [
  {
    id: 'skincare-essentials',
    title: 'Skincare Essentials',
    description: 'Master the fundamentals of a flawless skincare routine.',
    longDescription: 'Dive deep into understanding your skin type, choosing the right products, and establishing a daily regimen that combats common issues and promotes a healthy, radiant complexion. Learn about key ingredients and their benefits.',
    thumbnail: 'https://picsum.photos/seed/skincare/600/400',
    resources: [
      { id: 'vid-se-1', type: ResourceType.VIDEO, title: 'The Science of Skin: Types & Concerns', description: 'Understand your unique skin profile.', url: '#video1', thumbnail: 'https://picsum.photos/seed/skinv_1/300/200', duration: '12:45' },
      { id: 'vid-se-2', type: ResourceType.VIDEO, title: 'Building Your Morning Routine', description: 'Step-by-step guide to a powerful morning regimen.', url: '#video2', thumbnail: 'https://picsum.photos/seed/skinv_2/300/200', duration: '15:30' },
      { id: 'pdf-se-1', type: ResourceType.PDF, title: 'Skincare Ingredient Glossary', description: 'A comprehensive guide to common skincare ingredients.', url: '#pdf1', pages: 25 },
      { id: 'vid-se-3', type: ResourceType.VIDEO, title: 'Evening Skincare Rituals for Repair', description: 'Maximize overnight skin recovery.', url: '#video3', thumbnail: 'https://picsum.photos/seed/skinv_3/300/200', duration: '18:00' },
    ],
  },
  {
    id: 'hair-grooming',
    title: 'Hair Styling & Grooming',
    description: 'Achieve your ideal hairstyle and maintain healthy hair.',
    longDescription: 'Explore various hairstyles that suit different face shapes, learn advanced grooming techniques, and discover products that keep your hair healthy, strong, and stylish. From daily care to special occasion styling.',
    thumbnail: 'https://picsum.photos/seed/hair/600/400',
    resources: [
      { id: 'vid-hg-1', type: ResourceType.VIDEO, title: 'Choosing the Right Hairstyle for Your Face Shape', description: 'Find the most flattering cuts.', url: '#video4', thumbnail: 'https://picsum.photos/seed/hairv_1/300/200', duration: '10:15' },
      { id: 'pdf-hg-1', type: ResourceType.PDF, title: 'Hair Care Product Guide', description: 'Shampoos, conditioners, styling products explained.', url: '#pdf2', pages: 18 },
      { id: 'vid-hg-2', type: ResourceType.VIDEO, title: 'Mastering Hair Styling Techniques', description: 'From blow-drying to product application.', url: '#video5', thumbnail: 'https://picsum.photos/seed/hairv_2/300/200', duration: '20:05' },
    ],
  },
  {
    id: 'fitness-physique',
    title: 'Fitness & Physique',
    description: 'Sculpt your body with effective workout and nutrition plans.',
    longDescription: 'Learn foundational fitness principles, targeted workout routines for different body goals, and nutrition strategies that support muscle growth and fat loss. Create a sustainable fitness lifestyle.',
    thumbnail: 'https://picsum.photos/seed/fitness/600/400',
    resources: [
      { id: 'vid-fp-1', type: ResourceType.VIDEO, title: 'Beginner Full-Body Workout', description: 'Get started with foundational exercises.', url: '#video6', thumbnail: 'https://picsum.photos/seed/fitnessv_1/300/200', duration: '25:00' },
      { id: 'vid-fp-2', type: ResourceType.VIDEO, title: 'Nutrition for Muscle Gain', description: 'Fuel your body for growth.', url: '#video7', thumbnail: 'https://picsum.photos/seed/fitnessv_2/300/200', duration: '17:50' },
      { id: 'pdf-fp-1', type: ResourceType.PDF, title: '7-Day Lean Meal Plan', description: 'Sample meal plan for optimal results.', url: '#pdf3', pages: 15 },
    ],
  },
  {
    id: 'style-wardrobe',
    title: 'Style & Wardrobe',
    description: 'Develop a sharp personal style and build a versatile wardrobe.',
    longDescription: 'Discover your personal style archetype, learn how to choose clothes that fit and flatter, and build a capsule wardrobe that covers all occasions. Understand color theory and accessorizing.',
    thumbnail: 'https://picsum.photos/seed/style/600/400',
    resources: [
      { id: 'vid-sw-1', type: ResourceType.VIDEO, title: 'Finding Your Personal Style', description: 'Define your unique fashion identity.', url: '#video8', thumbnail: 'https://picsum.photos/seed/stylev_1/300/200', duration: '14:30' },
      { id: 'vid-sw-2', type: ResourceType.VIDEO, title: 'The Capsule Wardrobe: Essentials for Men', description: 'Build a versatile and timeless wardrobe.', url: '#video9', thumbnail: 'https://picsum.photos/seed/stylev_2/300/200', duration: '22:10' },
      { id: 'pdf-sw-1', type: ResourceType.PDF, title: 'Essential Style Guide: Fit & Color', description: 'Mastering the basics of good fit and color coordination.', url: '#pdf4', pages: 20 },
    ],
  },
  {
    id: 'mindset-confidence',
    title: 'Mindset & Confidence',
    description: 'Cultivate inner confidence and a powerful mindset.',
    longDescription: 'True transformation starts from within. This module focuses on techniques to build self-esteem, overcome limiting beliefs, improve social skills, and project confidence in all areas of life.',
    thumbnail: 'https://picsum.photos/seed/mindset/600/400',
    resources: [
      { id: 'vid-mc-1', type: ResourceType.VIDEO, title: 'The Power of Positive Self-Talk', description: 'Rewire your inner dialogue.', url: '#video10', thumbnail: 'https://picsum.photos/seed/mindsetv_1/300/200', duration: '16:00' },
      { id: 'vid-mc-2', type: ResourceType.VIDEO, title: 'Body Language for Confidence', description: 'Project confidence non-verbally.', url: '#video11', thumbnail: 'https://picsum.photos/seed/mindsetv_2/300/200', duration: '13:45' },
      { id: 'pdf-mc-1', type: ResourceType.PDF, title: 'Daily Confidence Building Exercises', description: 'Practical exercises to boost self-esteem.', url: '#pdf5', pages: 10 },
    ],
  },
];
