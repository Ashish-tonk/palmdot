
export interface User {
  email: string;
}

export enum ResourceType {
  VIDEO = 'video',
  PDF = 'pdf',
}

export interface Resource {
  id: string;
  type: ResourceType;
  title: string;
  description: string;
  url: string; // Placeholder URL, in a real app this would point to the actual resource
  thumbnail?: string; // Optional: for videos
  duration?: string; // Optional: for videos e.g., "10:35"
  pages?: number; // Optional: for PDFs
}

export interface Topic {
  id: string;
  title: string;
  description: string;
  longDescription?: string;
  thumbnail: string;
  resources: Resource[];
}

export interface AuthState {
  user: User | null;
  isLoading: boolean;
  error: string | null;
}

export interface GeneratedPlan {
  title: string;
  suggestions: string[];
}
